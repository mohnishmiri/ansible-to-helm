# DevPod — DevOps Workstation on AKS

A pod you `kubectl exec` into to do real development work. Includes Helm, k9s,
Docker (via DinD sidecar), Terraform, Ansible, Python/Node/Go/Rust toolchains,
all common network tools, Claude Code, and the cloud CLIs.

## What's inside

- **Kubernetes:** `kubectl`, `helm`, `k9s`, `stern`, `kustomize`, `kubectx`, `kubens`
- **IaC:** `terraform`, `packer`, `ansible`, `ansible-core`
- **Containers:** `docker` CLI (talks to DinD sidecar), `buildx`, `compose`
- **Cloud:** `az`, `aws`, `gcloud` (with GKE auth plugin)
- **Languages:** Python 3 + pipx + poetry + ruff, Node LTS + pnpm + yarn,
  Go (latest), Rust (stable via rustup)
- **AI dev:** Claude Code (`claude`)
- **VCS / CI:** `git`, `git-lfs`, `gh`, `pre-commit`, `yamllint`
- **Network tools:** `ping`, `traceroute`, `mtr`, `dig`, `host`, `nslookup`,
  `nmap`, `ncat`/`netcat`, `tcpdump`, `socat`, `telnet`, `whois`, `ipcalc`,
  `iproute2`, `nftables`, `iptables`, `httpie`, `curl`, `wget`, `openssl`
- **DB clients:** `psql`, `mysql`, `redis-cli`
- **Shell:** bash + zsh + tmux + fzf + ripgrep + bat + jq + yq

## Build & push the image

You need a container registry AKS can pull from. Easiest is Azure Container
Registry (ACR) attached to your AKS cluster.

```bash
# one-time: attach ACR to AKS so pulls auth automatically
az aks update -n <aks-name> -g <rg> --attach-acr <acr-name>

# build (use buildx for multi-arch if your cluster is arm64)
ACR=<acr-name>.azurecr.io
az acr login -n <acr-name>
docker build -t $ACR/devpod:latest .
docker push $ACR/devpod:latest
```

Then edit `devpod.yaml` and replace `REPLACE_ME/devpod:latest` with
`<acr-name>.azurecr.io/devpod:latest`.

## Deploy

```bash
kubectl apply -f devpod.yaml
kubectl -n devpod rollout status deploy/devpod
```

## Log in

```bash
kubectl exec -it -n devpod deploy/devpod -c devpod -- bash
```

You'll land in `/home/dev` as user `dev` with passwordless sudo. That directory
is on a 50Gi Azure Disk PVC, so anything you put there (cloned repos, kubeconfig,
`.ssh`, Claude Code state) survives pod restarts.

## Using Docker inside the pod

```bash
docker ps              # talks to the DinD sidecar at tcp://localhost:2375
docker build -t foo .
docker run --rm -it alpine sh
```

## Notes & tradeoffs

- The **DinD sidecar is privileged**. The main container where you work is not.
  If your cluster has Pod Security Standards set to `restricted`, label the
  namespace to allow privileged: `kubectl label ns devpod
  pod-security.kubernetes.io/enforce=privileged`.
- **One replica only** — PVCs are RWO. If you need multiple devs, give each
  their own Deployment + PVCs (templatize with Helm or Kustomize).
- **kubectl from inside the pod:** by default it has no kubeconfig. Either copy
  yours in (`kubectl cp ~/.kube/config devpod/<pod>:/home/dev/.kube/config`) or
  attach a ServiceAccount with the RBAC you need and use the in-cluster config.
- **Cost:** an idle Deployment still consumes node resources. Scale to 0 when
  not in use: `kubectl -n devpod scale deploy/devpod --replicas=0`.
- **Image size:** this image is ~3-4GB. To trim it, remove toolchains you don't
  need from the Dockerfile.
